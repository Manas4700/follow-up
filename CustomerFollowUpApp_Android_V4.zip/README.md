# Customer Follow-up Android App — Version 4.0

A polished single-user Android customer enquiry and follow-up app for showroom/finance work.

## V4 UI
- Modern dashboard with overview cards
- Quick actions
- Recent enquiries
- Dedicated overdue screen
- Calendar follow-up screen
- New enquiry with Finance/Cash selector
- Customer details with Call, WhatsApp, follow-up, reschedule and status
- Follow-up history
- PIN protection
- Daily reminder
- Backup/restore
- CSV export
- Reports
- English/Hindi setting placeholder

## Build
Open the project folder in Android Studio, allow Gradle sync, connect an Android phone, then Run.
For APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

Minimum Android: 8.0 (API 26).
Target Android: 15 (API 35).
