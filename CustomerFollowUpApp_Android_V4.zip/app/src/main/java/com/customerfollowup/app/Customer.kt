package com.customerfollowup.app

data class Customer(
    val id: Long,
    var name: String,
    var phone: String,
    var bike: String,
    var type: String,
    var financeCompany: String,
    var source: String,
    var notes: String,
    var nextFollowUp: Long,
    var status: String,
    var createdAt: Long,
    var history: MutableList<String> = mutableListOf()
)
