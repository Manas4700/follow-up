package com.customerfollowup.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import java.util.Calendar

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val now = System.currentTimeMillis()
        val start = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val end = start + 24L * 60 * 60 * 1000

        val all = CustomerStore.all(context)
        val today = all.count { it.nextFollowUp in start until end }
        val overdue = all.count {
            it.nextFollowUp < now && it.status !in listOf("Delivered", "Lost")
        }

        val channel = "daily_followups"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channel, "Daily follow-up summary", NotificationManager.IMPORTANCE_DEFAULT)
        )

        val text = if (today == 0 && overdue == 0)
            "Aaj koi pending follow-up nahi hai."
        else
            "Aaj: $today follow-ups • Overdue: $overdue"

        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Customer Follow-up")
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify(7001, n)
    }
}
