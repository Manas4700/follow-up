package com.customerfollowup.app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import java.security.MessageDigest

class LockActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("security", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (prefs.getString("pin_hash", null) == null) {
            showSetup()
        } else {
            showUnlock()
        }
    }

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun base(title: String, button: String, onClick: (String) -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
        }
        val titleView = TextView(this).apply {
            text = title; textSize = 26f
            setTypeface(typeface, 1)
            setPadding(0,0,0,32)
        }
        val pin = EditText(this).apply {
            hint = "4–6 digit PIN"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val btn = Button(this).apply { text = button }
        box.addView(titleView); box.addView(pin); box.addView(btn)
        setContentView(box)
        btn.setOnClickListener {
            val p = pin.text.toString()
            if (p.length !in 4..6) {
                Toast.makeText(this, "PIN 4–6 digits ka hona chahiye.", Toast.LENGTH_SHORT).show()
            } else onClick(p)
        }
    }

    private fun showSetup() {
        base("Customer Follow-up\nSet PIN", "Create PIN") { p ->
            prefs.edit().putString("pin_hash", hash(p)).apply()
            openApp()
        }
    }

    private fun showUnlock() {
        base("Customer Follow-up", "Unlock") { p ->
            if (hash(p) == prefs.getString("pin_hash", "")) openApp()
            else Toast.makeText(this, "Wrong PIN.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
