package com.customerfollowup.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object CustomerStore {
    private const val PREF = "customers"
    private const val KEY = "data"

    fun all(context: Context): MutableList<Customer> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val a = JSONArray(raw)
        val out = mutableListOf<Customer>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val h = mutableListOf<String>()
            val ha = o.optJSONArray("history") ?: JSONArray()
            for (j in 0 until ha.length()) h.add(ha.getString(j))
            out.add(Customer(
                o.getLong("id"), o.getString("name"), o.getString("phone"),
                o.optString("bike"), o.optString("type"), o.optString("financeCompany"),
                o.optString("source"), o.optString("notes"), o.optLong("nextFollowUp"),
                o.optString("status", "New"), o.optLong("createdAt"), h
            ))
        }
        return out.sortedByDescending { it.createdAt }.toMutableList()
    }

    fun toJson(context: Context): String {
        val a = JSONArray()
        all(context).forEach { c ->
            val o = JSONObject()
                .put("id", c.id).put("name", c.name).put("phone", c.phone)
                .put("bike", c.bike).put("type", c.type)
                .put("financeCompany", c.financeCompany).put("source", c.source)
                .put("notes", c.notes).put("nextFollowUp", c.nextFollowUp)
                .put("status", c.status).put("createdAt", c.createdAt)
            val h = JSONArray()
            c.history.forEach { h.put(it) }
            o.put("history", h)
            a.put(o)
        }
        return a.toString(2)
    }

    fun importJson(context: Context, raw: String): Int {
        val a = JSONArray(raw)
        var count = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val h = mutableListOf<String>()
            val ha = o.optJSONArray("history") ?: JSONArray()
            for (j in 0 until ha.length()) h.add(ha.getString(j))
            save(context, Customer(
                o.getLong("id"), o.getString("name"), o.getString("phone"),
                o.optString("bike"), o.optString("type"), o.optString("financeCompany"),
                o.optString("source"), o.optString("notes"), o.optLong("nextFollowUp"),
                o.optString("status", "New"), o.optLong("createdAt"), h
            ))
            count++
        }
        return count
    }

    fun save(context: Context, customer: Customer) {
        val list = all(context)
        list.removeAll { it.id == customer.id }
        list.add(customer)
        val a = JSONArray()
        list.forEach { c ->
            val o = JSONObject()
                .put("id", c.id).put("name", c.name).put("phone", c.phone)
                .put("bike", c.bike).put("type", c.type)
                .put("financeCompany", c.financeCompany).put("source", c.source)
                .put("notes", c.notes).put("nextFollowUp", c.nextFollowUp)
                .put("status", c.status).put("createdAt", c.createdAt)
            val h = JSONArray()
            c.history.forEach { h.put(it) }
            o.put("history", h)
            a.put(o)
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, a.toString()).apply()
    }

    fun delete(context: Context, id: Long) {
        val list = all(context).filter { it.id != id }
        val a = JSONArray()
        list.forEach { c ->
            val o = JSONObject()
                .put("id", c.id).put("name", c.name).put("phone", c.phone)
                .put("bike", c.bike).put("type", c.type)
                .put("financeCompany", c.financeCompany).put("source", c.source)
                .put("notes", c.notes).put("nextFollowUp", c.nextFollowUp)
                .put("status", c.status).put("createdAt", c.createdAt)
            val h = JSONArray(); c.history.forEach { h.put(it) }; o.put("history", h)
            a.put(o)
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, a.toString()).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
