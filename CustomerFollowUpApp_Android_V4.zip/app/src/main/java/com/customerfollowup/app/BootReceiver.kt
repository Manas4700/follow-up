package com.customerfollowup.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        scheduleDaily(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        CustomerStore.all(context).filter {
            it.nextFollowUp > System.currentTimeMillis() &&
            it.status !in listOf("Delivered", "Lost")
        }.forEach { c ->
            val i = Intent(context, FollowUpReceiver::class.java).putExtra("name", c.name)
            val pi = PendingIntent.getBroadcast(
                context, (c.id % Int.MAX_VALUE).toInt(), i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.nextFollowUp, pi)
            } catch (_: SecurityException) {}
        }
    }

    companion object {
        fun scheduleDaily(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 9)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val i = Intent(context, DailyReminderReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context, 9001, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                am.setInexactRepeating(
                    AlarmManager.RTC_WAKEUP,
                    cal.timeInMillis,
                    AlarmManager.INTERVAL_DAY,
                    pi
                )
            } catch (_: SecurityException) {}
        }
    }
}
