package com.customerfollowup.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var content: FrameLayout
    private lateinit var toolbar: com.google.android.material.appbar.MaterialToolbar
    private lateinit var nav: com.google.android.material.bottomnavigation.BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        toolbar = findViewById(R.id.toolbar)
        nav = findViewById(R.id.bottomNav)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        nav.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_home -> showDashboard()
                R.id.nav_enquiries -> showEnquiries()
                R.id.nav_add -> showForm(null)
                R.id.nav_followups -> showFollowUps()
                R.id.nav_reports -> showReports()
                R.id.nav_settings -> showSettings()
            }
            true
        }
        BootReceiver.scheduleDaily(this)
        showDashboard()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.rgb(35,35,45))
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }


    private fun showDashboard() {
        toolbar.title = "Dashboard"
        content.removeAllViews()

        val list = CustomerStore.all(this)
        val now = System.currentTimeMillis()
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0)
            set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
        }.timeInMillis
        val tomorrow = todayStart + 24L*60*60*1000
        val today = list.count { it.nextFollowUp in todayStart until tomorrow }
        val overdue = list.count { it.nextFollowUp < now && it.status !in listOf("Delivered","Lost") }
        val upcoming = list.count { it.nextFollowUp >= tomorrow && it.status !in listOf("Delivered","Lost") }
        val hot = list.count { it.status == "Hot" }
        val bookings = list.count { it.status == "Booking" }
        val delivered = list.count { it.status == "Delivered" }
        val lost = list.count { it.status == "Lost" }

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }

        val welcome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = getDrawable(R.drawable.rounded_card)
        }
        welcome.addView(tv("Good Morning 👋", 22f, true))
        welcome.addView(tv("Customer enquiries aur follow-ups yahin manage karein.", 14f))
        root.addView(welcome)

        root.addView(tv("Quick Overview", 18f, true))

        val grid = GridLayout(this).apply {
            columnCount = 2
            useDefaultMargins = true
        }

        fun addCard(label: String, value: Int, action: () -> Unit) {
            val card = TextView(this).apply {
                text = "$label\n$value"
                textSize = 16f
                setTypeface(typeface, 1)
                setPadding(dp(16), dp(16), dp(16), dp(16))
                background = getDrawable(R.drawable.rounded_card)
                setOnClickListener { action() }
            }
            grid.addView(card, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(88)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }

        addCard("Total Enquiries", list.size) { showEnquiries() }
        addCard("Today's Follow-ups", today) { showFollowUps() }
        addCard("⚠ Overdue", overdue) { showOverdue() }
        addCard("Upcoming", upcoming) { showFollowUps() }
        addCard("🔥 Hot Leads", hot) { showEnquiries() }
        addCard("Bookings", bookings) { showEnquiries() }
        addCard("Delivered", delivered) { showEnquiries() }
        addCard("Lost", lost) { showEnquiries() }

        root.addView(grid)
        root.addView(tv("Quick Actions", 18f, true))

        val newBtn = Button(this).apply {
            text = "＋  New Customer Enquiry"
            setOnClickListener { showForm(null) }
        }
        root.addView(newBtn)

        val todayBtn = Button(this).apply {
            text = "🔔  Today's Follow-ups"
            setOnClickListener { showFollowUps() }
        }
        root.addView(todayBtn)

        val reportBtn = Button(this).apply {
            text = "📊  Reports & Export"
            setOnClickListener { showReports() }
        }
        root.addView(reportBtn)

        root.addView(tv("Recent Enquiries", 18f, true))
        list.take(5).forEach { c ->
            val b = Button(this).apply {
                text = "${c.name}  •  ${c.status}\n${c.phone}  •  ${c.bike}"
                gravity = Gravity.START
                setOnClickListener { showCustomer(c.id) }
            }
            root.addView(b)
        }

        scroll.addView(root)
        content.addView(scroll)
    }

    private fun showOverdue() {
        toolbar.title = "Overdue Follow-ups"
        content.removeAllViews()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val list = CustomerStore.all(this).filter {
            it.nextFollowUp < System.currentTimeMillis() &&
            it.status !in listOf("Delivered","Lost")
        }.sortedBy { it.nextFollowUp }

        root.addView(tv("⚠ ${list.size} overdue follow-ups", 20f, true))
        if (list.isEmpty()) root.addView(tv("Great! No overdue follow-ups.", 16f))
        list.forEach { c ->
            val b = Button(this).apply {
                text = "⚠ ${c.name}\n${c.phone} • ${c.bike}\n${fmt(c.nextFollowUp)}"
                gravity = Gravity.START
                setOnClickListener { showCustomer(c.id) }
            }
            root.addView(b)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        content.addView(scroll)
    }

    private fun showEnquiries() {
        toolbar.title = "All Enquiries"
        content.removeAllViews()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(12),dp(12),dp(12))}
        val search=EditText(this).apply{hint="Search name or mobile";setSingleLine(true)}
        root.addView(search)
        val listBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(listBox)
        fun render(q:String="") {
            listBox.removeAllViews()
            CustomerStore.all(this).filter { it.name.contains(q,true)||it.phone.contains(q,true)||it.bike.contains(q,true) }.forEach { c ->
                val b=Button(this).apply {
                    text="${c.name} • ${c.phone}\n${c.bike} • ${c.status}"
                    gravity=Gravity.START; setPadding(dp(12),dp(10),dp(12),dp(10))
                    setOnClickListener { showCustomer(c.id) }
                }
                listBox.addView(b)
            }
        }
        search.addTextChangedListener(object: android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render(s?.toString()?:"")}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        render()
        val scroll=ScrollView(this); scroll.addView(root); content.addView(scroll)
    }

    private fun showForm(existing: Customer?) {
        toolbar.title = if(existing==null) "New Enquiry" else "Edit Enquiry"
        content.removeAllViews()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(14))}
        fun field(hint:String,value:String=""):EditText=EditText(this).apply{this.hint=hint;setText(value);setSingleLine(false);setPadding(dp(8),dp(8),dp(8),dp(8))}
        val name=field("Customer Name *",existing?.name?:"")
        val phone=field("Mobile Number *",existing?.phone?:""); phone.inputType=2
        val bike=field("Bike / Model",existing?.bike?:"")
        val type=Spinner(this)
        val types=arrayOf("Finance","Cash")
        type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,types)
        type.setSelection(types.indexOf(existing?.type ?: "Finance").coerceAtLeast(0))
        val finance=field("Finance Company",existing?.financeCompany?:"")
        val source=field("Enquiry Source (Walk-in / WhatsApp / Facebook / Referral)",existing?.source?:"")
        val notes=field("Customer Requirement / Notes",existing?.notes?:"")
        val dateBtn=Button(this)
        var followTime=existing?.nextFollowUp ?: (System.currentTimeMillis()+24*60*60*1000)
        fun updateDateText(){dateBtn.text="📅  Next Follow-up: ${fmt(followTime)}"}
        updateDateText()
        dateBtn.setOnClickListener{
            val cal=Calendar.getInstance().apply{timeInMillis=followTime}
            DatePickerDialog(this,{_,y,m,d->
                TimePickerDialog(this,{_,hh,mm->
                    cal.set(y,m,d,hh,mm,0);followTime=cal.timeInMillis;updateDateText()
                    },cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),true).show()
            },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        val status=Spinner(this); val statuses=arrayOf("New","Follow-up","Hot","Booking","Delivered","Lost")
        status.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,statuses)
        status.setSelection(statuses.indexOf(existing?.status ?: "New").coerceAtLeast(0))
        listOf(name,phone,bike).forEach{root.addView(it)}
        root.addView(type)
        listOf(finance,source,notes).forEach{root.addView(it)}
        root.addView(dateBtn); root.addView(status)
        val save=Button(this).apply{text="SAVE ENQUIRY"}
        root.addView(save)
        save.setOnClickListener{
            if(name.text.toString().trim().isEmpty()||phone.text.toString().trim().isEmpty()){
                Toast.makeText(this,"Name aur mobile number zaroor bharein.",Toast.LENGTH_SHORT).show();return@setOnClickListener
            }
            val c=existing ?: Customer(System.currentTimeMillis(),name.text.toString(),"","","","","","",followTime,"New",System.currentTimeMillis())
            c.name=name.text.toString();c.phone=phone.text.toString();c.bike=bike.text.toString()
            c.type=type.selectedItem.toString()
            c.financeCompany=finance.text.toString();c.source=source.text.toString();c.notes=notes.text.toString()
            c.nextFollowUp=followTime;c.status=status.selectedItem.toString()
            if(existing==null)c.history.add("Enquiry created • ${fmt(System.currentTimeMillis())}")
            CustomerStore.save(this,c);schedule(c)
            Toast.makeText(this,"Enquiry saved.",Toast.LENGTH_SHORT).show()
            showCustomer(c.id)
        }
        val scroll=ScrollView(this);scroll.addView(root);content.addView(scroll)
    }

    private fun showCustomer(id:Long){
        val c=CustomerStore.all(this).firstOrNull{it.id==id}?:return
        toolbar.title=c.name;content.removeAllViews()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(14))}
        root.addView(tv(c.name,24f,true));root.addView(tv("📞 ${c.phone}\n🏍 ${c.bike}\nStatus: ${c.status}",16f))
        root.addView(tv("Finance: ${c.financeCompany.ifBlank{"—"}}\nSource: ${c.source.ifBlank{"—"}}",14f))
        root.addView(tv("Notes:\n${c.notes.ifBlank{"—"}}",15f))
        root.addView(tv("Next follow-up: ${fmt(c.nextFollowUp)}",15f,true))
        val call=Button(this).apply{text="📞 Call";setOnClickListener{startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:${c.phone}")))}}
        val wa=Button(this).apply{text="🟢 WhatsApp";setOnClickListener{
            val url="https://wa.me/${c.phone.replace(Regex("\\D"),"")}"
            startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))
        }}
        val add=Button(this).apply{text="➕ Add Follow-up Note";setOnClickListener{addHistory(c)}}
        val reschedule=Button(this).apply{text="📅 Reschedule Follow-up";setOnClickListener{showForm(c)}}
        val edit=Button(this).apply{text="✏ Edit";setOnClickListener{showForm(c)}}
        val del=Button(this).apply{text="Delete";setOnClickListener{
            MaterialAlertDialogBuilder(this).setTitle("Delete enquiry?").setMessage("This customer record will be removed.")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->CustomerStore.delete(this,c.id);showEnquiries()}.show()
        }}
        listOf(call,wa,add,reschedule,edit,del).forEach{root.addView(it)}
        root.addView(tv("Follow-up History",18f,true))
        c.history.reversed().forEach{root.addView(tv("• $it",14f))}
        val scroll=ScrollView(this);scroll.addView(root);content.addView(scroll)
    }

    private fun addHistory(c:Customer){
        val input=EditText(this);input.hint="What happened in this follow-up?"
        MaterialAlertDialogBuilder(this).setTitle("Add Follow-up").setView(input)
            .setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                val note=input.text.toString().trim()
                if(note.isNotEmpty()){c.history.add("${fmt(System.currentTimeMillis())} • $note");c.status="Follow-up";CustomerStore.save(this,c)}
                showCustomer(c.id)
            }.show()
    }


    private fun showFollowUps(){
        toolbar.title="Follow-ups"
        content.removeAllViews()

        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(12),dp(8),dp(12),dp(12))
        }

        val calendar = CalendarView(this)
        root.addView(tv("📅 Select a date",18f,true))
        root.addView(calendar, LinearLayout.LayoutParams(-1, dp(300)))

        val selected = Calendar.getInstance()
        fun dayRange(cal: Calendar): Pair<Long,Long> {
            val c = cal.clone() as Calendar
            c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0)
            c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0)
            val s=c.timeInMillis
            return s to (s+24L*60*60*1000)
        }

        val listBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(tv("Customer Follow-ups",18f,true))
        root.addView(listBox)

        fun render(cal: Calendar) {
            listBox.removeAllViews()
            val (s,e)=dayRange(cal)
            val list=CustomerStore.all(this)
                .filter{it.nextFollowUp in s until e}
                .sortedBy{it.nextFollowUp}
            if(list.isEmpty()){
                listBox.addView(tv("Is date par koi follow-up scheduled nahi hai.",15f))
            } else {
                list.forEach{c->
                    val overdue=c.nextFollowUp < System.currentTimeMillis() &&
                        c.status !in listOf("Delivered","Lost")
                    val label=if(overdue) "⚠ OVERDUE" else c.status
                    val b=Button(this).apply{
                        text="${fmtTime(c.nextFollowUp)}  •  ${c.name}\n${c.phone} • ${c.bike}\n$label"
                        gravity=Gravity.START
                        setPadding(dp(12),dp(10),dp(12),dp(10))
                        setOnClickListener{showCustomer(c.id)}
                    }
                    listBox.addView(b)
                }
            }
        }

        calendar.setOnDateChangeListener { _,y,m,d->
            selected.set(y,m,d,12,0,0)
            render(selected)
        }
        render(selected)

        val overdueBtn=Button(this).apply{
            text="⚠ View All Overdue"
            setOnClickListener{
                listBox.removeAllViews()
                val list=CustomerStore.all(this@MainActivity)
                    .filter{it.nextFollowUp < System.currentTimeMillis() &&
                            it.status !in listOf("Delivered","Lost")}
                    .sortedBy{it.nextFollowUp}
                if(list.isEmpty()) listBox.addView(tv("No overdue follow-ups.",15f))
                list.forEach{c->
                    val b=Button(this@MainActivity).apply{
                        text="⚠ ${c.name}\n${fmt(c.nextFollowUp)} • ${c.status}"
                        gravity=Gravity.START
                        setOnClickListener{showCustomer(c.id)}
                    }
                    listBox.addView(b)
                }
            }
        }
        root.addView(overdueBtn)

        val scroll=ScrollView(this)
        scroll.addView(root)
        content.addView(scroll)
    }

    private fun showReports(){
        toolbar.title="Reports";content.removeAllViews()
        val list=CustomerStore.all(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(14))}
        root.addView(tv("Sales & Enquiry Report",22f,true))
        root.addView(tv("Total enquiries: ${list.size}",17f))
        listOf("New","Follow-up","Hot","Booking","Delivered","Lost").forEach{s->root.addView(tv("$s: ${list.count{it.status==s}}",16f))}
        val export=Button(this).apply{text="📤 Export CSV";setOnClickListener{exportCsv(list)}}
        root.addView(export)
        val backup=Button(this).apply{text="💾 Backup JSON";setOnClickListener{exportJson(list)}}
        root.addView(backup)
        val scroll=ScrollView(this);scroll.addView(root);content.addView(scroll)
    }

    private fun exportCsv(list:List<Customer>){
        val sb=StringBuilder("Name,Mobile,Bike,Type,Finance Company,Source,Status,Next Follow-up,Notes\n")
        list.forEach{c->sb.append(csv(c.name)).append(',').append(csv(c.phone)).append(',').append(csv(c.bike)).append(',')
            .append(csv(c.type)).append(',').append(csv(c.financeCompany)).append(',').append(csv(c.source)).append(',')
            .append(csv(c.status)).append(',').append(csv(fmt(c.nextFollowUp))).append(',').append(csv(c.notes)).append('\n')}
        shareText("Customer enquiries.csv","text/csv",sb.toString())
    }
    private fun exportJson(list:List<Customer>){
        val sb=StringBuilder()
        list.forEach{c->sb.append("${c.id}|${c.name}|${c.phone}|${c.bike}|${c.status}|${c.nextFollowUp}\n")}
        shareText("Customer backup.txt","text/plain",sb.toString())
    }
    private fun csv(s:String)= "\"${s.replace("\"","\"\"")}\""
    private fun shareText(name:String,type:String,text:String){
        val i=Intent(Intent.ACTION_SEND).apply{this.type=type;putExtra(Intent.EXTRA_TEXT,text);putExtra(Intent.EXTRA_SUBJECT,name)}
        startActivity(Intent.createChooser(i,"Export"))
    }


    private fun showSettings() {
        toolbar.title = "Settings"
        content.removeAllViews()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(tv("App Settings", 22f, true))

        val changePin = Button(this).apply {
            text = "🔐 Change PIN"
            setOnClickListener {
                val input = EditText(this@MainActivity).apply {
                    hint = "New 4–6 digit PIN"
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
                }
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Change PIN").setView(input)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Save") { _, _ ->
                        val p = input.text.toString()
                        if (p.length in 4..6) {
                            val hash = java.security.MessageDigest.getInstance("SHA-256")
                                .digest(p.toByteArray()).joinToString("") { "%02x".format(it) }
                            getSharedPreferences("security", MODE_PRIVATE).edit()
                                .putString("pin_hash", hash).apply()
                            Toast.makeText(this@MainActivity, "PIN updated.", Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(this@MainActivity, "PIN 4–6 digits ka hona chahiye.", Toast.LENGTH_SHORT).show()
                    }.show()
            }
        }
        root.addView(changePin)

        val backup = Button(this).apply {
            text = "💾 Create Full Backup"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "customer_followup_backup.json")
                }
                startActivityForResult(intent, 501)
            }
        }
        root.addView(backup)

        val restore = Button(this).apply {
            text = "♻ Restore Backup"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/json"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, 502)
            }
        }
        root.addView(restore)

        val language = Button(this).apply {
            text = "🌐 Language: English / Hindi"
            setOnClickListener {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Language")
                    .setItems(arrayOf("English", "Hindi")) { _, which ->
                        getSharedPreferences("settings", MODE_PRIVATE).edit()
                            .putString("language", if (which == 1) "hi" else "en").apply()
                        Toast.makeText(this@MainActivity,
                            if (which == 1) "Hindi selected. New screens will use Hindi labels where available."
                            else "English selected.", Toast.LENGTH_SHORT).show()
                    }.show()
            }
        }
        root.addView(language)

        val reminder = Button(this).apply {
            text = "🔔 Daily 9:00 AM Reminder: ON"
            setOnClickListener {
                BootReceiver.scheduleDaily(this@MainActivity)
                Toast.makeText(this@MainActivity, "Daily reminder 9:00 AM par schedule ho gaya.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(reminder)

        val clear = Button(this).apply {
            text = "⚠ Delete All Customer Data"
            setOnClickListener {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Delete all data?")
                    .setMessage("All enquiries and follow-up history on this phone will be deleted.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        CustomerStore.clear(this@MainActivity)
                        Toast.makeText(this@MainActivity, "All customer data deleted.", Toast.LENGTH_SHORT).show()
                        showDashboard()
                    }.show()
            }
        }
        root.addView(clear)
        root.addView(tv("\nVersion 2.0\nSingle-user • Local storage • PIN protected", 14f))

        val scroll = ScrollView(this)
        scroll.addView(root)
        content.addView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 501) {
                contentResolver.openOutputStream(uri)?.use {
                    it.write(CustomerStore.toJson(this).toByteArray())
                }
                Toast.makeText(this, "Backup saved.", Toast.LENGTH_SHORT).show()
            } else if (requestCode == 502) {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val count = CustomerStore.importJson(this, raw)
                Toast.makeText(this, "$count records restored/updated.", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Backup operation failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun schedule(c:Customer){
        if(c.nextFollowUp <= System.currentTimeMillis()) return
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        val intent=Intent(this,FollowUpReceiver::class.java).putExtra("name",c.name)
        val pi=PendingIntent.getBroadcast(this,(c.id%Int.MAX_VALUE).toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.nextFollowUp,pi) } catch(_:SecurityException) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:$packageName")))
        }
    }

    private fun fmt(t:Long)=SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date(t))
    private fun fmtTime(t:Long)=SimpleDateFormat("hh:mm a",Locale.getDefault()).format(Date(t))
}
